package com.code.booksystem.enums;

public enum UserRole {
    
	ADMIN,
	USER
}
